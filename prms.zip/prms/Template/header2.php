<hr>
<div class="dropdown" style="margin-left:5%;">
  <a href="#" class="d-flex align-items-center link-dark text-decoration-none dropdown-toggle" id="dropdownUser2" data-bs-toggle="dropdown" aria-expanded="false">
    <strong>&nbsp Berly</strong>
  </a>
  <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownUser2" style="width:10px">
    <li><a class="dropdown-item" href="#">Sign out</a></li>
  </ul>
</div>
<br>
</div>
<div class="b-example-divider"></div>
<div class="container">
